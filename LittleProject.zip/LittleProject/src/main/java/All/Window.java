package All;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JFileChooser;

public class Window extends javax.swing.JFrame {
    public static int Cantidad = 0;
    public static ArrayList <String> ListaA = new ArrawList();
    public static File FOLDER;
    public static String Localizacion;
    public static String TipoDeArchivo;
    public JFileChooser jf = new JFileChooser();
    
    public void Mostrar_Lista(){
    Console.setText("\n============================\n");
    for(String a : ListaA){
        Console.setText(a);
    }
    }
    public void Buscar_Archivos(File Directorio){
        //TipoDeArchivo=jList1.getSelectedValue();
        File Archivos[] = Directorio.listFiles();
        if(Archivos != null){
       for(int i =0;i<Archivos.length;i++){
           if(Archivos[i].isDirectory()){
               Buscar_Archivos(Archivos[i]);
           }else{
               if(Archivos[i].getName().endsWith("PNG"/*TipoDeArchivo*/)){
               Cantidad++;
               ListaA.add(Archivos[i].getName());
               }
           }
       }
    }
    }
    
    public Window() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        Console = new javax.swing.JTextField();
        Localizacion_Formate = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Buscador De Cantidad de Archivos");
        setBackground(new java.awt.Color(255, 255, 255));

        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Console.setBackground(new java.awt.Color(204, 204, 204));
        Console.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ConsoleActionPerformed(evt);
            }
        });

        Localizacion_Formate.setBackground(new java.awt.Color(153, 153, 153));
        Localizacion_Formate.setText("C:\\");

            jLabel1.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
            jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
            jLabel1.setText("Archivos");
            jLabel1.setMaximumSize(new java.awt.Dimension(60, 60));
            jLabel1.setMinimumSize(new java.awt.Dimension(60, 60));

            jButton2.setText("jButton2");
            jButton2.addActionListener(new java.awt.event.ActionListener() {
                public void actionPerformed(java.awt.event.ActionEvent evt) {
                    jButton2ActionPerformed(evt);
                }
            });

            jList1.setModel(new javax.swing.AbstractListModel<String>() {
                String[] strings = { "PNG", "JPG", "txt", "mp4" };
                public int getSize() { return strings.length; }
                public String getElementAt(int i) { return strings[i]; }
            });
            jList1.setAutoscrolls(false);
            jList1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
            jList1.setLayoutOrientation(javax.swing.JList.VERTICAL_WRAP);
            jScrollPane1.setViewportView(jList1);
            jList1.getAccessibleContext().setAccessibleName("Tipo_De_Archivos");

            javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
            getContentPane().setLayout(layout);
            layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(Console)
                            .addContainerGap())
                        .addGroup(layout.createSequentialGroup()
                            .addGap(10, 10, 10)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                                    .addGap(18, 18, 18)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addContainerGap(165, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(Localizacion_Formate)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(19, 19, 19))))))
            );
            layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(Console, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Localizacion_Formate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton2))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(29, 29, 29)
                            .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(22, 22, 22))
            );

            jButton1.getAccessibleContext().setAccessibleName("Boton_Buscar");
            Console.getAccessibleContext().setAccessibleName("Console");
            Localizacion_Formate.getAccessibleContext().setAccessibleName("Localizacion");

            pack();
        }// </editor-fold>//GEN-END:initComponents
//Boton De Busqueda
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    Localizacion=Localizacion_Formate.getValue().toString();
        Buscar_Archivos(new File(Localizacion));
    for(String a : ListaA){
       Console.setText("-" + a);
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ConsoleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ConsoleActionPerformed

    }//GEN-LAST:event_ConsoleActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
       //Abrir Pantalla de busqueda:
       jf.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
       jf.showOpenDialog(this);
       FOLDER= jf.getSelectedFile();
       if(FOLDER!= null){
           Localizacion_Formate.setText(FOLDER.getAbsolutePath());
       }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Window.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Window().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextField Console;
    public javax.swing.JFormattedTextField Localizacion_Formate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JList<String> jList1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables

    private static class ArrawList extends ArrayList<String> {

        public ArrawList() {
        }
    }

}
